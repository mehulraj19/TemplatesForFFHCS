import React, { useState } from "react";

function App() {
  const [contact, setContact] = useState({
    RegistrationNumber: "",
    email: ""
  });

  function handleChange(event) {
    const { name, value } = event.target;

    setContact((prevValue) => ({ ...prevValue, [name]: value }));
  }

  return (
    <div class="container mb-3">
      <h2 class="loginTitle">Log In</h2>
      <h2>Hello {contact.RegistrationNumber}</h2>
      <form>
        <input
          onChange={handleChange}
          name="RegistrationNumber"
          value={contact.RegistrationNumber}
          placeholder="Registration Number"
        />
        <input type="password" name="password" placeholder="Password" />
        <button type="submit" class="btn btn-primary content">
          Submit
        </button>
        <p>
          forgot Password? Click{" "}
          <a href="#" class="passTag">
            Here
          </a>
        </p>
      </form>
    </div>
  );
}

export default App;
